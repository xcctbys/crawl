
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.17.1'
version = '0.17.1'
full_version = '0.17.1'
git_revision = '0c44e977973b4c92dc1a5c235b9380f5b11ec45d'
release = True

if not release:
    version = full_version
