.. include:: ../README.rst

API
============

.. module:: ghost


Ghost
-----

.. autoclass:: Ghost
   :members:


Session
-------

.. autoclass:: Session
   :members:
