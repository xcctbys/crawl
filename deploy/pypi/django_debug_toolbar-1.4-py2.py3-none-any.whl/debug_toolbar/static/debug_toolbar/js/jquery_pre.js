var _djdt_define_backup = window.define; window.define = undefined;
