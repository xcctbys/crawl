from eventlet.support import six
assert six.PY3, 'This is a Python 3 module'
